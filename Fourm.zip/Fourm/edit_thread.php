<?php
include "Part/db_connect.php";
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    header("Location: login.php");
    exit();
}

$thread_id = $_GET['threadid'];
$user_id = $_SESSION['sno'];

// पहले थ्रेड के डेटा को लोड करें
$sql = "SELECT * FROM `threads` WHERE thread_id=$thread_id AND thread_user_id=$user_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    echo "Unauthorized access!";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_title = $_POST['thread_title'];
    $new_desc = $_POST['thread_description'];

    $update_sql = "UPDATE `threads` SET thread_title='$new_title', thread_description='$new_desc' WHERE thread_id=$thread_id";
    $update_result = mysqli_query($conn, $update_sql);

    if ($update_result) {
        header("Location: index.php?edit=success");
        exit();
    } else {
        echo "Error updating thread: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Thread</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Your Thread</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label for="thread_title">Problem Title</label>
                <input type="text" class="form-control" name="thread_title" value="<?php echo $row['thread_title']; ?>" required>
            </div>
            <div class="form-group">
                <label for="thread_description">Description</label>
                <textarea class="form-control" name="thread_description" rows="4" required><?php echo $row['thread_description']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-success">Update Thread</button>
            <a href="index.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
