<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <title>E-idea</title>
    <style>
        .jumbotron {
            background-color: #f8f9fa; /* Light gray background for jumbotron */
            padding: 4rem 2rem; /* Increased padding */
            margin-bottom: 2rem;
            border-radius: .3rem;
        }

        .jumbotron h1 {
            font-weight: 700; /* Bolder heading */
        }

        .thread-container {
            border: 1px solid #dee2e6; /* Light gray border */
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            background-color: #fff; /* White background */
        }

        .thread-title {
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }
        .thread-title a {
            color: #343a40; /* Darker link color */
            text-decoration: none;
        }
        .thread-title a:hover {
            color: #007bff; /* Highlight on hover */
        }

        .thread-meta {
            font-size: 0.9rem;
            color: #6c757d; /* Gray color for meta info */
            margin-bottom: 1rem;
        }
        .thread-description {
            margin-bottom: 1rem;
        }
        .btn-success {
            background-color: #28a745; /* Standard green */
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .alert-warning, .alert-success, .alert-danger {
          margin-top: 20px; /* Add some top margin to alerts */
        }
        .media img {
          border-radius: 50%; /* Make user images circular */
        }
    </style>
</head>

<body>
    <?php include "Part/_navbar.php"; ?>
    <?php include "Part/db_connect.php"; ?>

    <?php
    $id = $_GET['catid'];

    $sql = "SELECT * FROM `e-idea` WHERE card_id = $id";

    if ($result = mysqli_query($conn, $sql)) {
        while ($row = mysqli_fetch_assoc($result)) {
            $card_title = $row['card_title'];
            $card_description = $row['card_description'];
        }
    }
    ?>

    <div class="container">
        <div class="jumbotron my-5 "  style="background: linear-gradient(135deg, #2c3e50, #3498db ">
            <h1 class="display-4"><?php echo $card_title; ?></h1>
            <p class="lead"><?php echo $card_description; ?></p>
        </div>
    </div>

    <div class="container">
        <h1 class="py-2">Browse Questions</h1>





        
        <?php
        #yh code jab execute hoga jab user login hoga
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            echo '<form action="' . $_SERVER['REQUEST_URI'] . '" method="POST">
                <div class="form-group">
                    <label for="thread_title">Problem Title</label>
                    <input type="text" class="form-control" id="thread_title" name="thread_title" required>
                    <small class="form-text text-muted">Keep your title concise</small>
                </div>
                <div class="form-group">
                    <label for="thread_description">Elaborate Your Concern</label>
                    <textarea class="form-control" id="thread_description" name="thread_description" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
            </form>';
        } else {
            echo '<div class="alert alert-warning" role="alert">You need to be logged in to post a thread.</div>';
        }
        ?>

        <?php
        include "Part/db_connect.php";
        $id = $_GET['catid'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') #post request aya h and data ko database me insert krna h
        {
            $thread_title = $_POST['thread_title']; 
            $thread_description = $_POST['thread_description']; 
            $thread_cat_id = $id; #category id
            $thread_user_id = $_SESSION['sno'];

            if (!empty($thread_title) && !empty($thread_description)) {
                $sqlForthreads = "INSERT INTO `threads` (`thread_title`, `thread_description`, `thread_cat_id`,`thread_user_id`, `timestamp`) 
                                    VALUES ('$thread_title', '$thread_description', '$thread_cat_id','$thread_user_id', current_timestamp())";
                $result = mysqli_query($conn, $sqlForthreads);

                if ($result) {
                    echo '<div class="alert alert-success" role="alert">Your thread has been posted successfully!</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: Unable to post your thread. ' . mysqli_error($conn) . '</div>';
                }
            } else {
                echo '<div class="alert alert-warning" role="alert">Please fill in all the fields before submitting.</div>';
            }
        }
        ?>

        <?php
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `threads` WHERE thread_cat_id=$id";
        $result = mysqli_query($conn, $sql);
        $noResult = true;

        while ($row = mysqli_fetch_assoc($result)) {
            $noResult = false;
            $id = $row['thread_id']; #thread id
            $title = $row['thread_title'];
            $desc = $row['thread_description'];
            $thread_time = $row['timestamp'];
            $thread_user_id = $row['thread_user_id'];
        
            $sql2 = "SELECT user_email FROM `users` WHERE sno='$thread_user_id'";
            $result2 = mysqli_query($conn, $sql2);
            $row2 = mysqli_fetch_assoc($result2);
            $posted_by = $row2['user_email'];
        
            echo '<div class="thread-container my-5">
                    <h5 class="thread-title"><a href="threads.php?threadid=' . $id . '">' . $title . '</a></h5>
                    <div class="thread-meta">Asked by: ' . $posted_by . ' at ' . $thread_time . '</div>
                    <div class="thread-description">' . $desc . '</div>';
            
            // Edit और Delete बटन सिर्फ उसी यूजर को दिखें जिसने यह थ्रेड पोस्ट किया था
            if (isset($_SESSION['loggedin']) && $_SESSION['sno'] == $thread_user_id) {
                echo '<div>
                        <a href="edit_thread.php?threadid=' . $id . '" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_thread.php?threadid=' . $id . '" class="btn btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete this thread?\')">Delete</a>
                      </div>';
            }
        
            echo '</div>';
        }
        

        if ($noResult) {
            echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">No Threads Found</p>
                        <p class="lead"> Be the first person to ask a question</p>
                    </div>
                </div>';
        }
        ?>
    </div>

    <?php include "Part/_footer.php"; ?>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>