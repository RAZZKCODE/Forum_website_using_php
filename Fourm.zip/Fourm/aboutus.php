<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - E-idea Forum</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        .about-section {
            padding: 4rem 2rem; /* Increased padding */
        }
        .about-image {
            max-width: 100%;
            height: auto;
            border-radius: 8px; /* Rounded corners for the image */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
            margin-bottom: 2rem; /* Add some space below the image */
        }
        .team-member {
            margin-bottom: 2rem;
            text-align: center; /* Center the team member content */
        }
        .team-member img {
            width: 150px;
            height: 150px;
            border-radius: 50%; /* Make team member images circular */
            object-fit: cover; /* Ensure images cover the circle */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 1rem;
        }
        .team-member h3 {
            margin-bottom: 0.5rem;
        }
        .team-member p {
            color: #6c757d; /* Gray color for designations */
        }
    </style>
</head>

<body>
    <?php include "Part/_navbar.php"; ?>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <section class="about-section">
                    <h2 class="text-center mb-4">About E-idea Forum</h2>
                    <img src="placeholder-image.jpg" alt="About Us Image" class="about-image">  <p>Welcome to the E-idea Forum, a vibrant community dedicated to fostering innovation, collaboration, and the exchange of ideas. Our platform serves as a hub for individuals from all walks of life to connect, share their thoughts, and engage in meaningful discussions on a wide range of topics.</p>
                    <p>At E-idea, we believe that every idea has the potential to spark change and drive progress. Whether you're a seasoned professional, a passionate enthusiast, or simply curious about the world around you, you'll find a welcoming space here to explore new perspectives, learn from others, and contribute your own unique insights.</p>
                    <p>Our forum is built on the principles of respect, inclusivity, and open dialogue. We encourage all members to engage in constructive conversations, to listen attentively to different viewpoints, and to treat each other with courtesy and consideration. Together, we can create a thriving community where everyone feels valued and empowered to share their ideas.</p>

                    <h3>Our Mission</h3>
                    <p>To provide a platform that empowers individuals to connect, collaborate, and share ideas that shape the future.</p>

                    <h3>Our Vision</h3>
                    <p>To be the leading online community for fostering innovation and driving positive change through the exchange of ideas.</p>
                </section>

                <section class="about-section">
                <h2 class="text-center mb-4">Our Team</h2>
                    <div class="row">
                        <div class="col-md-4 team-member">
                            <img src="placeholder-profile.jpg" alt="Team Member 1"> <h3>John Doe</h3>
                            <p>Founder & CEO</p>
                        </div>
                        <div class="col-md-4 team-member">
                           <img src="placeholder-profile.jpg" alt="Team Member 2">  <h3>Jane Smith</h3>
                            <p>Community Manager</p>
                        </div>
                        <div class="col-md-4 team-member">
                           <img src="placeholder-profile.jpg" alt="Team Member 3">  <h3>David Lee</h3>
                            <p>Developer</p>
                        </div>
                        </div>
                </section>
            </div>
        </div>
    </div>

    <?php include "Part/_footer.php"; ?>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>