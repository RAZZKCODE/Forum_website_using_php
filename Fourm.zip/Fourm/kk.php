<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>E-idea</title>
</head>

<body>
  <?php include "Part/_navbar.php"; ?>
    <?php include "Part/db_connect.php"; ?>


 <!-- Form for thread submission -->
 <form action="" method="post">
            <div class="form-group">
                <label for="thread_title">Thread Title</label>
                <input type="text" class="form-control" id="thread_title" name="thread_title"
                    placeholder="Thread Title">
                <small id="emailHelp" class="form-text text-muted">Enter your problem or query title.</small>
            </div>
            <div class="form-group">
                <label for="thread_description">Thread Description</label>
                <textarea class="form-control" id="thread_description" rows="3" name="thread_description"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>

         
        </form>
   

      
      
      
      
     

        <?php
        include "Part/db_connect.php";
        
        
        // Handle thread submission
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Sanitize input to prevent SQL Injection
            $thread_title = $_POST['thread_title'];
            $thread_description = $_POST['thread_description'];
            $thread_cat_id = 3 ;// 3 is the category ID for e-idea

            // Validate input
            if (!empty($thread_title) && !empty($thread_description)) {
                // Insert thread into database
                $sqlForthreads = "INSERT INTO `threads` (`thread_title`, `thread_description`, `thread_cat_id`, `timestamp`) 
                                  VALUES ('$thread_title', '$thread_description', '$thread_cat_id', current_timestamp())";
                $result = mysqli_query($conn, $sqlForthreads);

                if ($result) {
                    echo '<div class="alert alert-success" role="alert">Your thread has been posted successfully!</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: Unable to post your thread. ' . mysqli_error($conn) . '</div>';
                }
            } else {
                echo '<div class="alert alert-warning" role="alert">Please fill in all the fields before submitting.</div>';
            }
        }
        ?>


<?php
        // Fetch threads for the category
        $sql = "SELECT * FROM threads WHERE thread_cat_id = 3";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while ($thread = mysqli_fetch_assoc($result)) {
                echo '
                <div class="media my-3">
                    <img src="user.png" width="60px" class="mr-3" alt="User Avatar">
                    <div class="media-body">
                        <h5 class="mt-0">
                            <a href="threads.php?threadid=' . $thread['thread_id'] . '">' . htmlspecialchars($thread['thread_title']) . '</a>
                        </h5>
                        <p>' . htmlspecialchars(substr($thread['thread_description'], 0, 150)) . '...</p>
                        <p class="text-muted">Posted on: ' . $thread['timestamp'] . '</p>
                    </div>
                </div>';
            }
        } else {
            echo '<div class="jumbotron jumbotron-fluid mt-3">
                    <div class="container">
                        <p class="lead">No threads found. Be the first to ask a question!</p>
                    </div>
                  </div>';
        }
        ?>





<?php include "Part/_footer.php"; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>