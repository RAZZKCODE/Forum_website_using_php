<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>E-idea</title>
    <style>
        /* Custom size for the carousel */
        #carouselExampleIndicators {
            max-width: 800px; /* Adjust the width */
            margin: 0 auto; /* Center the carousel */
        }

        #carouselExampleIndicators img {
            object-fit: cover; /* Ensure the images fit nicely */
            max-height: 500px; /* Match the carousel height */
            width: 100%; /* Ensure images stretch to carousel width */
        }
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Add a subtle shadow */
            transition: transform 0.2s; /* Add a hover effect */
        }

        .card:hover {
            transform: translateY(-5px); /* Move card up slightly on hover */
            background-color: #B2FFFF; /* Lighten the background color */
  
        }
        .card-img-top {
          height: 200px; /* Set a fixed height for card images */
          object-fit: cover; /* Maintain aspect ratio and cover the area */
        }
        .card-title a {
            color: #343a40; /* Darker link color for better contrast */
            text-decoration: none; /* Remove underline from links */
        }

        .card-title a:hover {
            color: #007bff; /* Highlight color on hover */
        }
        .btn-primary {
            background-color: #007bff; /* Use a more modern blue */
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
    </style>
</head>

<body>
    <?php include "Part/_navbar.php"; ?>



    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></button>
            <button type="button" data-target="#carouselExampleIndicators" data-slide-to="1"></button>
            <button type="button" data-target="#carouselExampleIndicators" data-slide-to="2"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="i (1).jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="i (2).jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="i (3).jpg" class="d-block w-100" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="container my-4">
        <h3>All Categories</h3>
        <div class="row">
            <?php
            include "Part/db_connect.php";

            $sql = "SELECT * FROM `e-idea`";
            $result = mysqli_query($conn, $sql);

            while ($row = mysqli_fetch_assoc($result)) {
                // Extract data
                $card_id = $row['card_id'];
                $card_title = $row['card_title'];
                $card_description = $row['card_description'];
                $timestamp = $row['timestamp'];

                // Output card
                echo '<div class="col-md-4 my-2 d-flex align-items-stretch">
                        <div class="card" style="width: 18rem;">
                            <img src="Article-Image-945×498.jpg" class="card-img-top" alt="image for this category">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <a href="threadlist.php?catid=' . $card_id . '">' . $card_title . '</a>
                                </h5>
                                <p class="card-text">' . substr($card_description, 0, 90) . '...</p>
                                <p class="text-muted">Posted on: ' . $timestamp . '</p>
                                <a href="threadlist.php?catid=' . $card_id . '" class="btn btn-primary">View Threads</a>
                            </div>
                        </div>
                    </div>';
            }
            ?>

        </div>
    </div>



    <?php include "Part/_footer.php"; ?>


    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yfoRSJoZ+n"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
</body>

</html>