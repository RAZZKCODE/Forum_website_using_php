<!-- Include Bootstrap CSS if you haven't already -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style>
    .modal-content {
        border-radius: 15px;
        border: none;
    }
    .modal-header {
        background-color:  #3498db; /* Bootstrap success color */
        color: white;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
    }
    .modal-body {
        background-color: #f9f9f9; /* Light background for body */
    }
    .form-control {
        border-radius: 10px;
    }
    .btn-success {
        background-color:  #3498db; /* Darker green for button */
        border-radius: 10px;
    }
    .btn-success:hover {
        background-color:rgb(33, 86, 136); /* Darker green on hover */
    }
    .modal-footer {
        background-color: #f9f9f9; /* Match modal body background */
        border-bottom-left-radius: 15px;
        border-bottom-right-radius: 15px;
    }
</style>

<!-- Modal -->
<div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="signupModalLabel">Signup for an E-Idea Account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="part/_handleSignup.php" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label for="signupEmail">Username</label>
            <input type="text" class="form-control" id="signupEmail" name="signupEmail" aria-describedby="emailHelp" required>
          </div>
          <div class="form-group">
            <label for="signupPassword">Password</label>
            <input type="password" class="form-control" id="signupPassword" name="signupPassword" required>
          </div>
          <div class="form-group">
            <label for="signupcPassword">Confirm Password</label>
            <input type="password" class="form-control" id="signupcPassword" name="signupcPassword" required>
          </div>

          <button type="submit" class="btn btn-success">Signup</button>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Include Bootstrap JS and dependencies if you haven't already -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>