<?php
$showError = "false";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db_connect.php';

    $user_email = $_POST['signupEmail'];
    $pass = $_POST['signupPassword'];
    $cpass = $_POST['signupcPassword'];

    // Check whether this email exists (using prepared statement)
    $existSql = "SELECT * FROM `users` WHERE user_email = ?";
    $stmt = $conn->prepare($existSql);
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $result = $stmt->get_result();
    $numRows = $result->num_rows;
    $stmt->close();


    if ($numRows > 0) {
        $showError = "Email already in use";
    } else {
        if ($pass == $cpass) {
            $hash = password_hash($pass, PASSWORD_DEFAULT);

            // Insert user data (using prepared statement)
            $sql = "INSERT INTO `users` (`user_email`, `user_pass`, `timestamp`) VALUES (?, ?, current_timestamp())";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $user_email, $hash);
            $stmt->execute();


            if ($stmt->affected_rows > 0) {
                header("Location: /PHPfiles/Fourm/index.php?signupsuccess=true");
                exit();
            } else {
                $showError = "Error during signup. Please try again.";
            }
            $stmt->close();

        } else {
            $showError = "Passwords do not match";
        }
    }
    header("Location: /PHPfiles/Fourm/index.php?signupsuccess=false&error=" . urlencode($showError)); // urlencode for safety
    exit(); // Important: Stop further execution after redirect
}
?>