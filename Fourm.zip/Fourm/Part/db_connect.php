<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "e-idea";

// Create a connection
$conn = mysqli_connect($server, $username, $password, $database);

// Check if the connection was successful
if (!$conn) {

    die("Error: " . mysqli_connect_error());
}
?>


