<?php


echo "Logging you in. Please wait...";
$showError = "false";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db_connect.php';
    $email = $_POST['loginEmail'];
    $pass = $_POST['loginPass'];

    // Prepared Statement for SELECT
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_email = ?");
    $stmt->bind_param("s", $email); // "s" for string
    $stmt->execute();
    $result = $stmt->get_result();
    $numRows = $result->num_rows;
    $stmt->close();

    if ($numRows == 1) {
        $row = $result->fetch_assoc(); // Use fetch_assoc() after get_result()

        if (password_verify($pass, $row['user_pass'])) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['sno'] = $row['sno'];
            $_SESSION['useremail'] = $email;
            // Removed echo for cleaner redirect
            header("Location: /PHPfiles/Fourm/index.php?loginSuccess=true"); // Added success parameter
            exit(); // Important: Stop further execution
        } else {
          $showError = "Incorrect Password";
        }
    } else {
        $showError = "User Not Found"; // More specific error message
    }

    header("Location: /PHPfiles/Fourm/index.php?loginSuccess=false&error=" . urlencode($showError)); // Redirect with error
    exit(); // Always exit after redirect
}
?>