<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-idea</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background: linear-gradient(135deg, #2c3e50, #3498db);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
            color: #ecf0f1 !important;
            transition: all 0.3s ease;
        }
        
        .navbar-brand:hover {
            transform: scale(1.05);
        }
        
        .nav-link {
            color: #ecf0f1 !important;
            font-weight: 500;
            margin: 0 10px;
            transition: all 0.2s ease;
        }
        
        .nav-link:hover {
            color: #bdc3c7 !important;
            transform: translateY(-2px);
        }
        
        .dropdown-menu {
            background-color: #f8f9fa;
            border: none;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .dropdown-item:hover {
            background-color: #3498db;
            color: white !important;
        }
        
        .btn-custom {
            background-color: #2980b9;
            color: white;
            border: none;
            transition: all 0.3s ease;
        }
        
        .btn-custom:hover {
            background-color: #1a5f8c;
            transform: translateY(-2px);
        }
        
        .welcome-message {
            color: #ecf0f1 !important;
            font-weight: 500;
            margin-right: 15px;
        }
        
        .search-input {
            border-radius: 20px;
            padding: 8px 20px;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    $loggedin = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true;

    echo '<nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">E-IDEA</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="aboutus.php">About Us</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" 
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Categories
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Tech</a></li>
                            <li><a class="dropdown-item" href="#">Fun</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Other</a></li>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex align-items-center">';

                if($loggedin){
                    echo '
                    <form class="d-flex me-3">
                        <input class="form-control search-input me-2" type="search" placeholder="Search">
                        <button class="btn btn-custom" type="submit">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                    <span class="welcome-message">Welcome, '.$_SESSION['useremail'].'</span>
                    <a href="part/_logout.php" class="btn btn-custom">
                        Logout <i class="bi bi-box-arrow-right"></i>
                    </a>';
                } else {
                    echo '
                    <button class="btn btn-custom me-2" data-bs-toggle="modal" data-bs-target="#loginModal">
                        Login <i class="bi bi-box-arrow-in-right"></i>
                    </button>
                    <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#signupModal">
                        Sign Up <i class="bi bi-person-plus"></i>
                    </button>';
                }

                echo '</div>
            </div>
        </div>
    </nav>';

    include 'loginmodal.php';
    include 'singupmodal.php';

    if(isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == "true"){
        echo '<div class="alert alert-success alert-dismissible fade show my-0" role="alert">
                <strong>Success!</strong> You can now login
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    }
    ?>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
</body>
</html>