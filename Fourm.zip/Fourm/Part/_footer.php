<div class="container-fluid text-center bg-dark text-light mb-0">
    copyright 2025
</div>