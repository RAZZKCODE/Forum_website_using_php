<?php
echo 
include "Part/db_connect.php";
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $thread_title = $_POST['thread_title'];
            $thread_description= $_POST['thread_description'];
            
            // Insert thread using prepared statement
            $sql = "INSERT INTO `threads` (`thread_id`, `thread_title`, `thread_description`, `thread_cat_id`, `timestamp`) VALUES (NULL, '$thread_title', '$thread_description', '2', current_timestamp())";
            $stmt = mysqli_query($conn, $sql);
            if ($stmt) {
                echo '<div class="alert alert-success mt-3">Thread posted successfully!</div>';
            } else {
                echo '<div class="alert alert-danger mt-3">Error posting thread.</div>';
            }
        }
        ?>

        <div class="container">
            <h1 class="py-2">Browse Questions</h1>

            <!-- Thread Submission Form -->
            <form action="<?php echo ($_SERVER['REQUEST_URI']); ?>" method="post">
                <div class="form-group">
                    <label for="thread_title">Problem Title</label>
                    <input type="text" class="form-control" id="thread_title" name="thread_title" required>
                    <small class="form-text text-muted">Keep your title concise</small> 
                </div>
                <div class="form-group">
                    <label for="thread_description">Elaborate Your Concern</label>
                    <textarea class="form-control" id="thread_description" name="thread_description" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
    