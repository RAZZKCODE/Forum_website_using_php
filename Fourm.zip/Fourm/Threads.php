<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <title>Thread Replies</title>
    <style>
        .jumbotron {
            background-color: #f8f9fa;
            padding: 4rem 2rem;
            margin-bottom: 2rem;
            border-radius: .3rem;
        }

        .jumbotron h1 {
            font-weight: 700;
        }

        .reply-container {
            border: 1px solid #dee2e6;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }
        .reply-meta {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 1rem;
        }
        .reply-content {
            margin-bottom: 1rem;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        .alert-warning,
        .alert-success,
        .alert-danger {
            margin-top: 20px;
        }

        .media img {
            border-radius: 50%;
        }
    </style>
</head>

<body>
    <?php include "Part/_navbar.php"; ?>
    <?php include "Part/db_connect.php"; ?>

    <?php
    $id = isset($_GET['threadid']) ? intval($_GET['threadid']) : 0;

    $sql = "SELECT * FROM `threads` WHERE thread_id = $id";
    $result = mysqli_query($conn, $sql);
    $thread_title = "Unknown Category";
    $thread_description = "No description available for this category.";
    $posted_by = "Unknown"; // Initialize posted_by

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $thread_title = $row['thread_title'];
            $thread_description = $row['thread_description'];
            $thread_user_id = $row['thread_user_id'];

            $sql2 = "SELECT user_email FROM `users` WHERE sno='$thread_user_id'";
            $result2 = mysqli_query($conn, $sql2);
            if ($result2 && mysqli_num_rows($result2) > 0) { // Check if user exists
                $row2 = mysqli_fetch_assoc($result2);
                $posted_by = $row2['user_email'];
            }
        }
    }
    ?>

    <div class="container my-4">
        <div class="jumbotron">
            <h1 class="display-4"><?php echo $thread_title; ?></h1>
            <p class="lead"><?php echo $thread_description ?></p>
            <hr class="my-4">
            <p><b>Posted By: <?php echo $posted_by; ?></b></p>
            <p>Discuss and share your thoughts below!</p>
        </div>

        <?php
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
            echo '<form action="' . ($_SERVER['REQUEST_URI']) . '" method="POST">
                <div class="form-group">
                    <label for="reply_content">Reply</label>
                    <textarea class="form-control" id="reply_content" name="reply_content" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Submit</button>
            </form>';
        } else {
            echo '<div class="alert alert-warning" role="alert">Please login to post a reply.</div>';
        }
        ?>

        <?php
        include "Part/db_connect.php";
        $id = $_GET['threadid'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $reply_content = $_POST['reply_content'];
            $thread_id = $id;
            $reply_user_id = $_SESSION['sno'];

            if (!empty($reply_content)) {
                $sqlForreply = "INSERT INTO `replies` (`reply_user_id`, `reply_content`, `thread_id`, `timestamp`) 
                                VALUES ( '$reply_user_id', '$reply_content', '$thread_id', current_timestamp());";
                $result = mysqli_query($conn, $sqlForreply);

                if ($result) {
                    echo '<div class="alert alert-success" role="alert">Your Reply has been posted successfully!</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: Unable to post your reply. ' . mysqli_error($conn) . '</div>';
                }
            } else {
                echo '<div class="alert alert-warning" role="alert">Please fill in the reply field before submitting.</div>';
            }
        }
        ?>

        <?php
        $id = $_GET['threadid'];
        $sql = "SELECT * FROM replies WHERE thread_id = $id";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($thread = mysqli_fetch_assoc($result)) {
                $thread_id = $thread['thread_id'];
                $reply_content = $thread['reply_content'];
                $timestamp = $thread['timestamp'];
                $reply_user_id = $thread['reply_user_id'];

                $sql2 = "SELECT user_email FROM `users` WHERE sno='$reply_user_id'";
                $result2 = mysqli_query($conn, $sql2);
                $posted_by = "Unknown"; // Initialize posted_by for replies

                if ($result2 && mysqli_num_rows($result2) > 0) {
                    $row2 = mysqli_fetch_assoc($result2);
                    $posted_by = $row2['user_email'];
                }

                echo '
                <div class="reply-container my-5">
                    <div class="reply-meta">Posted by: ' . $posted_by . ' at ' . $timestamp . '</div>
                    <div class="reply-content">' . htmlspecialchars(substr($reply_content, 0, 200)) . '</div>
                </div>';
            }
        } else {
            echo '<div class="jumbotron jumbotron-fluid mt-3">
                    <div class="container">
                        <p class="lead">No Reply found.!</p>
                    </div>
                </div>';
        }
        ?>
    </div>

    <?php include "Part/_footer.php"; ?>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>